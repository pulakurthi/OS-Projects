import matplotlib.pyplot as plt

# Parse the data
samples = []
pid_data = {4: {'tickets': 30, 'ticks': []}, 
            5: {'tickets': 20, 'ticks': []}, 
            6: {'tickets': 10, 'ticks': []}}

# Read and parse the file
with open('lottery_output.txt', 'r') as f:
    lines = f.readlines()
    
    for i, line in enumerate(lines):
        if line.startswith('Tick sample'):
            sample_num = int(line.split()[2].rstrip(':'))
            samples.append(sample_num)
            
            # Read the next 3 lines for pid data
            for j in range(1, 4):
                if i + j < len(lines):
                    data_line = lines[i + j].strip()
                    if data_line.startswith('pid'):
                        parts = data_line.split()
                        pid = int(parts[1].rstrip(':'))
                        ticks = int(parts[5])
                        pid_data[pid]['ticks'].append(ticks)

# Create figure
plt.figure(figsize=(12, 6))

# Plot absolute ticks over time
for pid in [4, 5, 6]:
    plt.plot(samples, pid_data[pid]['ticks'], 
             label=f'PID {pid} ({pid_data[pid]["tickets"]} tickets)', 
             marker='o', markersize=4)

plt.xlabel('Sample Number')
plt.ylabel('Total Ticks')
plt.title('CPU Ticks Allocation Over Time - Lottery Scheduler')
plt.legend()
plt.grid(True, alpha=0.3)

plt.tight_layout()
plt.savefig('lottery_ticks_over_time.png', dpi=300, bbox_inches='tight')
plt.show()
