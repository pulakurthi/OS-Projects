/***************************************************************************
file name - lotterytest.c
run the following command to generate the input file for plot_lottery_output.py 
make qemu > lottery_output.txt
run lotterytest
python plot_lottery_output.py 
*****************************************************************************/
#include "types.h"
#include "stat.h"
#include "user.h"
#include "pstat.h"

#define NUM_CHILDREN 3

int main(void) {
  int children[NUM_CHILDREN];
  int tickets[NUM_CHILDREN] = {30,20,10};
  struct pstat ps;
  int i, j;

  // Fork children and set their tickets
  for (i = 0; i < NUM_CHILDREN; i++) {
    int pid = fork();
    if (pid == 0) {
      settickets(tickets[i]);
      while (1) { /* spin to use CPU */ }
      exit();
    } else {
      children[i] = pid;
    }
  }

  // Parent: print stats periodically
  for (j = 0; j < 50; j++) {
    sleep(100); // sleep for a while
    if (getpinfo(&ps) < 0) {
      printf(1, "getpinfo failed\n");
      break;
    }
    printf(1, "Tick sample %d:\n", j);
    for (i = 0; i < NUM_CHILDREN; i++) {
      int idx;
      // Find the child in the pstat table
      for (idx = 0; idx < NPROC; idx++) {
        if (ps.inuse[idx] == 1 && ps.pid[idx] == children[i]) {
          printf(1, "  pid %d: tickets %d, ticks %d\n", ps.pid[idx], ps.tickets[idx], ps.ticks[idx]);
        }
      }
    }
    printf(1, "\n");
  }

  // Kill children and wait
  for (i = 0; i < NUM_CHILDREN; i++) {
    kill(children[i]);
    wait();
  }
  exit();
}
